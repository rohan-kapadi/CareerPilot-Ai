/**
 * Popup Script — AI Resume Builder Chrome Extension
 * Handles login, ATS analysis rendering, and one-click skill sync.
 */

const loginView = document.getElementById('login-view');
const dashboardView = document.getElementById('dashboard-view');
const loginForm = document.getElementById('login-form');
const loginError = document.getElementById('login-error');
const logoutBtn = document.getElementById('ext-logout-btn');

const scoreValue = document.getElementById('score-value');
const scoreRing = document.getElementById('score-ring');
const matchedChips = document.getElementById('matched-chips');
const missingChips = document.getElementById('missing-chips');
const userSkillsChips = document.getElementById('user-skills-chips');
const skillsCountBadge = document.getElementById('skills-count-badge');
const statusBar = document.getElementById('status-bar');
const statusText = document.getElementById('status-text');
const analyzeBtn = document.getElementById('ext-analyze-btn');
const loginBtn = document.getElementById('ext-login-btn');
const tailorBtn = document.getElementById('ext-tailor-btn');
const tailorAction = document.getElementById('tailor-action');

const CIRCUMFERENCE = 2 * Math.PI * 54;
const STATUS_TONES = ['status-success', 'status-error', 'status-warning'];
const ANALYZE_BUTTON_TEXT = analyzeBtn
  ? analyzeBtn.innerHTML
  : '<span class="icon">✦</span>Analyze job on this page';

initialize();

function initialize() {
  resetAnalysisView();

  chrome.runtime.sendMessage({ type: 'GET_STATUS' }, (response) => {
    if (response && response.isLoggedIn) {
      showDashboard();
      loadUserSkills();
      loadAnalysis();
    } else {
      showLogin();
      setStatus('Sign in to analyze jobs and sync skills.', 'warning');
    }
  });

  if (loginForm) {
    loginForm.addEventListener('submit', handleLoginSubmit);
  }

  if (logoutBtn) {
    logoutBtn.addEventListener('click', handleLogout);
  }

  if (analyzeBtn) {
    analyzeBtn.addEventListener('click', analyzeActiveTab);
  }

  if (tailorBtn) {
    tailorBtn.addEventListener('click', generateTailoredResume);
  }

  chrome.storage.onChanged.addListener((changes) => {
    if (changes.lastAnalysis && changes.lastAnalysis.newValue) {
      renderAnalysis(changes.lastAnalysis.newValue);
    }

    if (changes.userSkills && changes.userSkills.newValue) {
      renderUserSkills(changes.userSkills.newValue);
    }
  });
}

function handleLoginSubmit(event) {
  event.preventDefault();
  loginError.textContent = '';

  const emailInput = document.getElementById('ext-email');
  const passwordInput = document.getElementById('ext-password');
  const email = emailInput ? emailInput.value.trim() : '';
  const password = passwordInput ? passwordInput.value : '';

  if (!email || !password) {
    loginError.textContent = 'Email and password are required.';
    setStatus('Email and password are required.', 'error');
    return;
  }

  setButtonLoading(loginBtn, true, 'Signing in...');

  chrome.runtime.sendMessage({ type: 'LOGIN', email, password }, (response) => {
    setButtonLoading(loginBtn, false, 'Sign In');

    if (response && response.error) {
      loginError.textContent = response.error;
      setStatus('Login failed. Check your credentials.', 'error');
      return;
    }

    showDashboard();
    setStatus('Logged in. Open a job page and analyze.', 'success');
    loadUserSkills();
    loadAnalysis();
  });
}

async function handleLogout() {
  await chrome.storage.local.remove(['jwt', 'user', 'lastAnalysis', 'userSkills']);
  showLogin();
  resetAnalysisView();
  setStatus('Signed out from extension.', 'warning');
}

function showLogin() {
  loginView.classList.remove('hidden');
  dashboardView.classList.add('hidden');
}

function showDashboard() {
  loginView.classList.add('hidden');
  dashboardView.classList.remove('hidden');
}

function analyzeActiveTab() {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (!tabs || !tabs[0]) {
      setStatus('Cannot access active tab.', 'error');
      return;
    }

    setAnalyzeLoading(true);

    chrome.tabs.sendMessage(tabs[0].id, { type: 'EXTRACT_JD' }, (jd) => {
      if (chrome.runtime.lastError || !jd || !jd.trim()) {
        const message = chrome.runtime.lastError
          ? chrome.runtime.lastError.message
          : 'Could not extract job description from this page.';
        setStatus(message, 'error');
        setAnalyzeLoading(false);
        return;
      }

      setStatus('Analyzing job requirements...', 'warning');
      chrome.runtime.sendMessage({ type: 'JOB_DESC', payload: jd }, (response) => {
        setAnalyzeLoading(false);

        if (response && response.error) {
          setStatus(`Error: ${response.error}`, 'error');
          return;
        }

        setStatus('Analysis complete.', 'success');
      });
    });
  });
}

function loadUserSkills() {
  chrome.runtime.sendMessage({ type: 'GET_USER_SKILLS' }, (response) => {
    const skills = (response && response.skills) || [];
    renderUserSkills(skills);
  });
}

function renderUserSkills(skills) {
  userSkillsChips.innerHTML = '';
  skillsCountBadge.textContent = String(skills.length);

  if (!skills.length) {
    const empty = document.createElement('p');
    empty.className = 'empty-state';
    empty.textContent = 'No profile skills yet.';
    userSkillsChips.appendChild(empty);
    return;
  }

  skills.forEach((skill) => {
    const chip = document.createElement('span');
    chip.className = 'chip chip-user';
    chip.textContent = skill;
    userSkillsChips.appendChild(chip);
  });
}

async function loadAnalysis() {
  const { lastAnalysis } = await chrome.storage.local.get(['lastAnalysis']);
  if (!lastAnalysis) {
    resetAnalysisView();
    setStatus('No analysis yet. Visit a job page and run analysis.', 'warning');
    return;
  }

  renderAnalysis(lastAnalysis);
}

function resetAnalysisView() {
  if (tailorAction) tailorAction.classList.add('hidden');
  
  scoreValue.textContent = '—';
  scoreRing.style.strokeDashoffset = String(CIRCUMFERENCE);

  matchedChips.innerHTML = '';
  missingChips.innerHTML = '';

  const matchedEmpty = document.createElement('p');
  matchedEmpty.className = 'empty-state';
  matchedEmpty.textContent = 'Matched skills will appear after analysis.';

  const missingEmpty = document.createElement('p');
  missingEmpty.className = 'empty-state';
  missingEmpty.textContent = 'Missing skills will appear after analysis.';

  matchedChips.appendChild(matchedEmpty);
  missingChips.appendChild(missingEmpty);
}

function renderAnalysis(data) {
  if (tailorAction) tailorAction.classList.remove('hidden');

  const score = Math.max(0, Math.min(100, data.atsScore || 0));
  const matched = Array.isArray(data.matchedSkills) ? data.matchedSkills : [];
  const missing = Array.isArray(data.missingSkills) ? data.missingSkills : [];

  animateScore(score);

  matchedChips.innerHTML = '';
  renderReadonlySkillChips(
    matchedChips,
    matched,
    'chip chip-matched',
    'No matched skills in this job yet.'
  );

  missingChips.innerHTML = '';
  if (!missing.length) {
    const empty = document.createElement('p');
    empty.className = 'empty-state';
    empty.textContent = 'No missing skills detected.';
    missingChips.appendChild(empty);
  } else {
    missing.forEach((skill) => {
      const chip = document.createElement('button');
      chip.type = 'button';
      chip.className = 'chip chip-missing';
      chip.textContent = `+ ${skill}`;
      chip.title = 'Click to add this skill to your resume and profile';
      chip.addEventListener('click', () => addMissingSkill(skill, chip));
      missingChips.appendChild(chip);
    });
  }

  const total = matched.length + missing.length;
  setStatus(`Matched ${matched.length}/${total || 0} skills`, 'success');
}

function renderReadonlySkillChips(container, skills, chipClass, emptyMessage) {
  if (!skills.length) {
    const empty = document.createElement('p');
    empty.className = 'empty-state';
    empty.textContent = emptyMessage;
    container.appendChild(empty);
    return;
  }

  skills.forEach((skill) => {
    const chip = document.createElement('span');
    chip.className = chipClass;
    chip.textContent = skill;
    container.appendChild(chip);
  });
}

function animateScore(target) {
  const finalTarget = Math.max(0, Math.min(100, target));
  const duration = 1200;
  const startTime = performance.now();

  function update(now) {
    const elapsed = now - startTime;
    const progress = Math.min(elapsed / duration, 1);
    const eased = 1 - Math.pow(1 - progress, 3);
    const current = Math.round(finalTarget * eased);

    scoreValue.textContent = String(current);

    const offset = CIRCUMFERENCE - (CIRCUMFERENCE * current) / 100;
    scoreRing.style.strokeDashoffset = String(offset);

    // 600/700-weight shades: the previous 400-weight values were tuned for the
    // old dark popup and wash out against the light card background.
    if (current >= 75) {
      scoreRing.style.stroke = '#059669';
      scoreValue.style.color = '#059669';
    } else if (current >= 50) {
      scoreRing.style.stroke = '#b45309';
      scoreValue.style.color = '#b45309';
    } else {
      scoreRing.style.stroke = '#dc2626';
      scoreValue.style.color = '#dc2626';
    }

    if (progress < 1) {
      requestAnimationFrame(update);
    }
  }

  requestAnimationFrame(update);
}

function addMissingSkill(skill, chipEl) {
  chipEl.classList.add('is-loading');
  chipEl.disabled = true;
  chipEl.textContent = `... ${skill}`;

  chrome.runtime.sendMessage({ type: 'ADD_SKILL', skill }, (response) => {
    if (response && response.error) {
      chipEl.classList.remove('is-loading');
      chipEl.disabled = false;
      chipEl.textContent = `+ ${skill}`;
      setStatus(`Error: ${response.error}`, 'error');
      return;
    }

    chipEl.className = 'chip chip-matched is-added';
    chipEl.textContent = `✓ ${skill}`;
    chipEl.disabled = true;

    setStatus(`Added "${skill}" to your profile.`, 'success');
    loadUserSkills();
  });
}

function setStatus(message, tone = 'warning') {
  statusText.textContent = message;
  statusBar.classList.remove(...STATUS_TONES);
  if (tone && tone !== 'info') {
    statusBar.classList.add(`status-${tone}`);
  }
}

function setAnalyzeLoading(loading) {
  if (!analyzeBtn) return;
  analyzeBtn.disabled = loading;
  analyzeBtn.innerHTML = loading
    ? '<span class="icon">...</span>Analyzing...'
    : ANALYZE_BUTTON_TEXT;
}

function setButtonLoading(button, loading, loadingLabel) {
  if (!button) return;
  if (!button.dataset.defaultText) button.dataset.defaultText = button.innerHTML;
  button.disabled = loading;
  button.innerHTML = loading ? loadingLabel : button.dataset.defaultText;
}

async function generateTailoredResume() {
  setButtonLoading(tailorBtn, true, '<span class="icon">...</span>Generating (this takes a moment)...');
  setStatus('Tailoring resume to job (takes up to 10s)...', 'warning');
  
  chrome.runtime.sendMessage({ type: 'GENERATE_TAILORED' }, async (response) => {
    if (response && response.error) {
      setButtonLoading(tailorBtn, false, null);
      setStatus(`Error: ${response.error}`, 'error');
      return;
    }
    
    // response is the JSON
    try {
      setStatus('Generating PDF...', 'warning');
      const { jwt } = await chrome.storage.local.get(['jwt']);
      const exportRes = await fetch('http://localhost:5000/api/job/tailor/export/pdf', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${jwt}` },
        body: JSON.stringify({ sections: response }),
      });
      if (!exportRes.ok) throw new Error('PDF Generation failed');
      
      const blob = await exportRes.blob();
      const reader = new FileReader();
      reader.onload = () => {
        chrome.downloads.download({
          url: reader.result,
          filename: 'Tailored_Resume.pdf',
          saveAs: true
        }, (downloadId) => {
          if (chrome.runtime.lastError) {
            setStatus(`Download Error: ${chrome.runtime.lastError.message}`, 'error');
          } else {
            setStatus('Tailored PDF downloaded!', 'success');
          }
          setButtonLoading(tailorBtn, false, null);
        });
      };
      reader.onerror = () => {
        setStatus('Error converting PDF blob to data URL.', 'error');
        setButtonLoading(tailorBtn, false, null);
      };
      reader.readAsDataURL(blob);
    } catch (e) {
      setStatus(`Error: ${e.message}`, 'error');
      setButtonLoading(tailorBtn, false, null);
    }
  });
}
